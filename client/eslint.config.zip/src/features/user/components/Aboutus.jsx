import React from "react"
import { Heart, UserPlus, Sparkles, MessageCircleHeart } from "lucide-react"
import priyaProfileImg from "../../../assets/priya_profile.jpg"

export default function Aboutus() {
  return (
    <section id="how-it-works" className="relative overflow-hidden py-16 sm:py-20 lg:py-24 px-4 sm:px-6 lg:px-8 bg-white">
      {/* Background Soft Fluid Glow */}
      <div className="absolute top-1/4 -left-20 -z-10 w-[500px] h-[500px] bg-gradient-to-br from-[#FFE7F0]/60 via-[#7C3AED]/10 to-transparent blur-3xl rounded-full pointer-events-none" />

      {/* Floating Ambient Heart Accents */}
      <div className="absolute top-12 left-10 text-[#FF2D72]/40 pointer-events-none">
        <Heart className="w-5 h-5 fill-[#FF2D72]/30" />
      </div>
      <div className="absolute bottom-16 right-16 text-[#FF2D72]/30 pointer-events-none">
        <Heart className="w-6 h-6 fill-[#FF2D72]/20" />
      </div>

      <div className="max-w-[1600px] mx-auto relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">

          {/* Left Column: Overlapping "It's a Match!" Polaroids Visual */}
          <div className="lg:col-span-6 relative flex justify-center items-center py-6 sm:py-10">
            {/* Background Soft Radiant Glow */}
            <div className="absolute w-[80%] h-[80%] bg-gradient-to-tr from-[#FFE7F0] via-[#FF2D72]/10 to-[#7C3AED]/10 rounded-full blur-3xl pointer-events-none" />

            {/* Overlapping Photo Cards Wrapper */}
            <div className="relative w-full max-w-[460px] h-[360px] sm:h-[400px] flex items-center justify-center">

              {/* Left Photo Card: Woman Portrait (Tilted Left) */}
              <div className="absolute left-2 sm:left-6 top-4 sm:top-2 w-[190px] sm:w-[220px] h-[260px] sm:h-[300px] rounded-[24px] sm:rounded-[28px] bg-white p-2.5 shadow-2xl shadow-[#FF2D72]/15 transform -rotate-6 hover:-rotate-2 transition-all duration-500 overflow-hidden border border-[#FFE7F0] z-10 group">
                <div className="w-full h-full rounded-[18px] sm:rounded-[22px] overflow-hidden">
                  <img
                    src={priyaProfileImg}
                    alt="LoveConnect Member - Woman"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
              </div>

              {/* Right Photo Card: Handsome Man Portrait (Tilted Right) */}
              <div className="absolute right-2 sm:right-6 top-10 sm:top-8 w-[190px] sm:w-[220px] h-[260px] sm:h-[300px] rounded-[24px] sm:rounded-[28px] bg-white p-2.5 shadow-2xl shadow-[#7C3AED]/15 transform rotate-6 hover:rotate-2 transition-all duration-500 overflow-hidden border border-purple-100 z-10 group">
                <div className="w-full h-full rounded-[18px] sm:rounded-[22px] overflow-hidden">
                  <img
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=600&q=80"
                    alt="LoveConnect Member - Man"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                </div>
              </div>

              {/* Central Floating Heart Badge */}
              <div className="absolute z-20 w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-gradient-to-tr from-[#FF2D72] to-[#ff4a86] p-1 shadow-xl shadow-[#FF2D72]/40 flex items-center justify-center text-white border-4 border-white animate-pulse">
                <Heart className="w-7 h-7 fill-white text-white" />
              </div>

              {/* "It's a Match!" Pill Badge (Bottom Left) */}
              <div className="absolute -bottom-3 left-6 sm:left-10 z-30 px-5 py-2 rounded-full bg-gradient-to-r from-[#FF2D72] to-[#ff4a86] text-white font-extrabold text-xs sm:text-sm shadow-xl shadow-[#FF2D72]/30 tracking-wide border-2 border-white transform -rotate-3 hover:rotate-0 transition-transform duration-300">
                It's a Match!
              </div>

            </div>
          </div>

          {/* Right Column: "HOW IT WORKS" & 3 Steps */}
          <div className="lg:col-span-6 flex flex-col justify-center">

            {/* Eyebrow Badge */}
            <div className="inline-block self-start mb-4">
              <span className="px-3.5 py-1 rounded-full bg-[#FFE7F0] text-[#FF2D72] text-xs font-bold tracking-wider uppercase border border-[#FF2D72]/20">
                HOW IT WORKS
              </span>
            </div>

            {/* Main Heading */}
            <h2 className="text-3xl sm:text-4xl lg:text-[44px] font-black text-[#17151A] tracking-tight leading-[1.15] mb-5">
              A Simple Way to <br className="hidden sm:inline" />
              Find{" "}
              <span className="bg-gradient-to-r from-[#FF2D72] via-[#ff4382] to-[#7C3AED] bg-clip-text text-transparent">
                Real Connections
              </span>
            </h2>

            {/* Subtitle / Mission Paragraph */}
            <p className="text-[#64748b] text-base sm:text-lg leading-relaxed font-normal mb-9 max-w-xl">
              LoveConnect makes it easy to meet new people, chat, and build meaningful relationships. Whether you're looking for love, friendship, or companionship — we're here to help.
            </p>

            {/* 3 Numbered Steps Row (Matching Image 1) */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-1">

              {/* Step 1 */}
              <div className="flex flex-col items-start group">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-10 h-10 rounded-full bg-[#FFE7F0] border border-[#FF2D72]/20 flex items-center justify-center text-[#FF2D72] group-hover:bg-[#FF2D72] group-hover:text-white transition-all duration-300 shadow-xs">
                    <UserPlus className="w-4.5 h-4.5" />
                  </div>
                  <span className="text-xs font-bold text-[#FF2D72] bg-[#FFE7F0] px-2 py-0.5 rounded-full border border-[#FF2D72]/20">
                    01
                  </span>
                </div>
                <h4 className="font-bold text-[#17151A] text-sm sm:text-base leading-snug">
                  Create Your Profile
                </h4>
                <p className="text-xs text-[#64748b] font-normal mt-1 leading-relaxed">
                  Sign up and tell us about yourself.
                </p>
              </div>

              {/* Step 2 */}
              <div className="flex flex-col items-start group">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-10 h-10 rounded-full bg-purple-50 border border-purple-100 flex items-center justify-center text-[#7C3AED] group-hover:bg-[#7C3AED] group-hover:text-white transition-all duration-300 shadow-xs">
                    <Sparkles className="w-4.5 h-4.5" />
                  </div>
                  <span className="text-xs font-bold text-[#7C3AED] bg-purple-50 px-2 py-0.5 rounded-full border border-purple-100">
                    02
                  </span>
                </div>
                <h4 className="font-bold text-[#17151A] text-sm sm:text-base leading-snug">
                  Discover Matches
                </h4>
                <p className="text-xs text-[#64748b] font-normal mt-1 leading-relaxed">
                  Find people with similar interests.
                </p>
              </div>

              {/* Step 3 */}
              <div className="flex flex-col items-start group">
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-50 border border-emerald-100 flex items-center justify-center text-[#22C55E] group-hover:bg-[#22C55E] group-hover:text-white transition-all duration-300 shadow-xs">
                    <MessageCircleHeart className="w-4.5 h-4.5" />
                  </div>
                  <span className="text-xs font-bold text-[#22C55E] bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                    03
                  </span>
                </div>
                <h4 className="font-bold text-[#17151A] text-sm sm:text-base leading-snug">
                  Start Connecting
                </h4>
                <p className="text-xs text-[#64748b] font-normal mt-1 leading-relaxed">
                  Like, chat and build real relationships.
                </p>
              </div>

            </div>

          </div>

        </div>
      </div>
    </section>
  )
}
