import { Link, NavLink } from "react-router-dom"
import { Search } from "lucide-react"
import Logo from "../../../assets/loveconnect.png"

export default function Navbar() {
  const navItems = [
    { name: "Home", path: "/" },
    { name: "Features", path: "/#features" },
    { name: "How It Works", path: "/#how-it-works" },
    { name: "Pricing", path: "/#pricing" },
    { name: "Success Stories", path: "/#testimonials" },
  ]

  return (
    <header className="w-full bg-white/95 backdrop-blur-md sticky top-0 z-50 border-b border-[#FFE7F0]">
      <nav className="max-w-[1600px] mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Logo Section */}
        <div className="flex items-center shrink-0">
          <Link to="/" className="flex items-center gap-2">
            <img src={Logo} className="h-10 sm:h-20 w-auto object-contain" alt="LoveConnect Logo" />
          </Link>
        </div>

        {/* Navigation Links */}
        <div className="hidden md:flex items-center justify-center gap-7 lg:gap-9">
          {navItems.map((item) => (
            <NavLink
              key={item.name}
              to={item.path}
              end={item.path === "/"}
              className={({ isActive }) =>
                `text-sm font-semibold transition-colors duration-200 ${isActive
                  ? "text-[#FF2D72]"
                  : "text-[#17151A]/70 hover:text-[#FF2D72]"
                }`
              }
            >
              {item.name}
            </NavLink>
          ))}
        </div>

        {/* Actions Section */}
        <div className="flex items-center gap-3 sm:gap-4">
          <button
            aria-label="Search"
            className="w-9 h-9 rounded-full flex items-center justify-center text-[#17151A]/70 hover:text-[#FF2D72] hover:bg-[#FFE7F0]/60 transition-all duration-200 cursor-pointer"
          >
            <Search className="w-4.5 h-4.5" />
          </button>
          <Link
            to="/login"
            className="px-5 py-2 rounded-full border border-[#FF2D72]/30 text-[#FF2D72] hover:bg-[#FFE7F0]/60 font-semibold text-sm transition-all duration-200 cursor-pointer flex items-center justify-center shadow-xs"
          >
            Login
          </Link>
          <Link
            to="/register"
            className="px-5.5 py-2 rounded-full bg-[#FF2D72] hover:bg-[#e61b61] text-white font-semibold text-sm transition-all duration-200 shadow-md shadow-[#FF2D72]/20 cursor-pointer flex items-center justify-center"
          >
            Get Started
          </Link>
        </div>
      </nav>
    </header>
  )
}
