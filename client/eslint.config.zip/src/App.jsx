import Home from "./features/user/pages/Home"


function App() {


  return (
    <>
      <Home />
    </>
  )
}

export default App
